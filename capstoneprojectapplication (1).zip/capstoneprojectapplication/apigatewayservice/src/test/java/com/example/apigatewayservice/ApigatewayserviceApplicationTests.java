package com.example.apigatewayservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApigatewayserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
