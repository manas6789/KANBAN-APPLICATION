package com.example.eurekaclientserverdiscovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaclientserverdiscoveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
