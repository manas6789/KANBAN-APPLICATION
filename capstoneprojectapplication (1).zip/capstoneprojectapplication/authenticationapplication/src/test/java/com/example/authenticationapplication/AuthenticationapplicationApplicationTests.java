package com.example.authenticationapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
