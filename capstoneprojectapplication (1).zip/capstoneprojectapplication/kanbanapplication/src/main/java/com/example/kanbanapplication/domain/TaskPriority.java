package com.example.kanbanapplication.domain;

public enum TaskPriority {
    HIGH,NORMAL,LOW,URGENT
}
