package com.example.kanbanapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KanbanapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
