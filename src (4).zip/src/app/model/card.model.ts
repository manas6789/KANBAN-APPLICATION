export class Card {
    cardName:String|undefined|null="";
    taskPriority:any;
    description:String|undefined|null="";
    category:String|undefined|null="";
    cardAssignee:String|undefined|null="";
}
