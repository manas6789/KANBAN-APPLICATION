import { Column } from './column.model';

describe('Column', () => {
  it('should create an instance', () => {
    expect(new Column()).toBeTruthy();
  });
});
