import { LoginUser } from './login-user.model';

describe('LoginUser', () => {
  it('should create an instance', () => {
    expect(new LoginUser()).toBeTruthy();
  });
});
