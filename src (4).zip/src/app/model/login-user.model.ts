export class LoginUser {
    userEmailID:String|undefined|null;
    userPassword:String|undefined|null;
}
